async function validar() {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim(); 
   
    if (email !== "" && password !== "") {
        const verificar = loginvalidation(email, password);
        const validation = await verificar;

        if (validation != null) {
            alert('Autenticación exitosa. Bienvenido ' + email);
            window.location.href = '../templates/home.html';
        } else {
            alert('Error de autenticación. Verifica tu correo y contraseña.');
            console.log('Error de autenticación para el correo: ' + email);
        }
    } else {
        alert('Por favor, completa todos los campos.');
    }
}
