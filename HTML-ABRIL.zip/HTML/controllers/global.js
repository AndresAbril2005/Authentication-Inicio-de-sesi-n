
document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("loginForm");
  const logoutBtn = document.getElementById("logoutBtn");

  loginForm.addEventListener("submit", function (event) {
      event.preventDefault(); 
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

  
      login(email, password);
  });

  logoutBtn.addEventListener("click", function () {

      logout();
  });
});
function login(email, password) {
  console.log("Logging in with email:", email, "and password:", password);

  alert("Logged in successfully!");
  window.location.href = "templates/home.html";
}



function logout() {
  
  console.log("Logging out...");

  alert("Logged out successfully!");
  document.getElementById("logoutBtn").style.display = "none";
}
